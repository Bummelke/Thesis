#libraries
library(ggplot2)
library(readxl)
library(dplyr)
library(tidyverse)
library(deSolve)
library(rgl)
library(cocor)

#scriptie Netlogo data classic
data_classic <- read.csv("ecosysteem model classic Pop dynamics scriptie-spreadsheet.csv", header = FALSE) #lees excel in (wel al schoongemaakt - automatiseren?)
datalist <- list()

for(i in 1:nrow(data_classic)){                                   #loop door de lines heen en maak ze clean nummers
  splitted <- strsplit(data_classic[i,1], ",")[[1]]
  splitted <- splitted[splitted != ""]
  splitted <- gsub('"', '', splitted)
  num <- as.numeric(splitted)

  mat <- matrix(num, ncol = 4, byrow=TRUE)
  
  datalist[[i]] <- mat
}

final_mat <- do.call(rbind, datalist)                        #1 grote matrix met time en pop counts

data1 <- as.data.frame(final_mat)
colnames(data1) <- c("Time1", "Foxes1", "Rabbits1", "Grass1")
data1$Experiment <- rep(1:10) # geef er even aan welke van de runs van netlogo het is, wordt eerst gezet als alles met time 0, alles met time 1 enz. 

#for Experiment 1-10 (als test)############################

data_list <- lapply(1:10, function(i) {
  data_exp <- data1 %>% filter(Experiment == i)
  data_long <- pivot_longer(data_exp, cols = c("Foxes1", "Rabbits1", "Grass1"),
                            names_to = "Variable", values_to = "Value")
  
  list(
    Foxes1   = subset(data_long, Variable == "Foxes1"),
    Rabbits1 = subset(data_long, Variable == "Rabbits1"),
    Grass1   = subset(data_long, Variable == "Grass1")
  )
})

Foxes1 <- data_list[[1]]$Foxes1
Foxes1$Value <- (data_list[[1]]$Foxes1$Value + data_list[[2]]$Foxes1$Value + data_list[[3]]$Foxes1$Value +
                   data_list[[4]]$Foxes1$Value + data_list[[5]]$Foxes1$Value + data_list[[6]]$Foxes1$Value +
                   data_list[[7]]$Foxes1$Value + data_list[[8]]$Foxes1$Value + data_list[[9]]$Foxes1$Value +
                   data_list[[10]]$Foxes1$Value) / 10

# Rabbits
Rabbits1 <- data_list[[1]]$Rabbits1
Rabbits1$Value <- (data_list[[1]]$Rabbits1$Value + data_list[[2]]$Rabbits1$Value + data_list[[3]]$Rabbits1$Value +
                     data_list[[4]]$Rabbits1$Value + data_list[[5]]$Rabbits1$Value + data_list[[6]]$Rabbits1$Value +
                     data_list[[7]]$Rabbits1$Value + data_list[[8]]$Rabbits1$Value + data_list[[9]]$Rabbits1$Value +
                     data_list[[10]]$Rabbits1$Value) / 10

# Grass
Grass1 <- data_list[[1]]$Grass1
Grass1$Value <- (data_list[[1]]$Grass1$Value + data_list[[2]]$Grass1$Value + data_list[[3]]$Grass1$Value +
                   data_list[[4]]$Grass1$Value + data_list[[5]]$Grass1$Value + data_list[[6]]$Grass1$Value +
                   data_list[[7]]$Grass1$Value + data_list[[8]]$Grass1$Value + data_list[[9]]$Grass1$Value +
                   data_list[[10]]$Grass1$Value) / 10
Grass1$Value <- Grass1$Value / 4

#############################################################
#plot time
################################################################################################
combined_df <- bind_rows(
  Foxes1 %>% mutate(Variable = "Foxes"),
  Rabbits1 %>% mutate(Variable = "Rabbits"),
  Grass1 %>% mutate(Variable = "Grass")
)
p <- ggplot(combined_df, aes(x = Time1, y = Value, color = Variable)) +
  geom_line(linewidth = 1) +
  scale_color_manual(values = c("Foxes" = "red", "Rabbits" = "blue", "Grass" = "green")) +
  scale_y_continuous(limits = c(0, 1500)) +
  scale_x_continuous(limits = c(1000, 1500)) +
  labs(title = "Population over Time", x = "Time", y = "Value") +
  theme_minimal(base_size = 14)
print(p)
ggsave("Population_over_Time_1.png", plot = p, width = 8, height = 5, dpi = 300)
####################################################################################################

#PLOT BASE CA1 phase space
################################################################################################################
###############################################################################################################
rgl.open()
bg3d(col = "white")  # clean background
view3d(theta = 45, phi = 30, zoom = 0.8)
par3d(windowRect = c(0, 0, 1300, 1000))  # 1100x1100 pixels window
plot3d(Rabbits1$Value, Foxes1$Value, Grass1$Value, col = "#346699", size = 2, box = FALSE, xlab = "" , ylab = "", zlab = "", xlim = range(380, 750), ylim = range(100, 350), zlim = range(700, 1300))

rgl.snapshot("CA13dview.png")
###################################################################################################################
p1 <- ggplot(data.frame(Rabbits = Rabbits1$Value, Grass = Grass1$Value), aes(x = Rabbits, y = Grass)) +
  geom_point(alpha = 0.6, color = "#346699", size = 1) +
  labs(x = "Rabbits", y = "Grass", title = "Rabbits vs Grass CA0") +
  lims(x = range(350, 750), y = range(700, 1300))+ 
  theme_minimal()

print(p1)

# Save to file
ggsave("Rabbits_vs_Grass.png", plot = p1, width = 7, height = 5, dpi = 300)
###################################################################################################################

p2 <- ggplot(data.frame(Foxes = Foxes1$Value, Grass = Grass1$Value), aes(x = Foxes, y = Grass)) +
  geom_point(shape = 16, alpha = 0.6, color = "#346699", size = 1) +
  labs(x = "Foxes", y = "Grass", title = "Foxes vs Grass CA0") +
  lims(x = range(100, 350), y = range(700, 1300))+ 
  theme_minimal()

print(p2)

# Save to file
ggsave("Foxes_vs_Grass.png", plot = p2, width = 7, height = 5, dpi = 300)
###################################################################################################################

p3 <- ggplot(data.frame(Foxes = Foxes1$Value, Rabbits = Rabbits1$Value), aes(x = Foxes, y = Rabbits)) +
  geom_point(alpha = 0.6, color = "#346699", size = 1) +
  labs(x = "Foxes", y = "Rabbits", title = "Foxes vs Rabbits CA0") +
  lims(x = range(100, 350), y = range(350, 750))+ 
  theme_minimal()

print(p3)

# Save to file
ggsave("Foxes_vs_Rabbits.png", plot = p3, width = 7, height = 5, dpi = 300)

#################################################################################################################
#################################################################################################################
#################################################################################################################
#################################################################################################################
#################################################################################################################
#################################################################################################################
#################################################################################################################
###################################P L O T             2   ####################################################
#################################################################################################################
#################################################################################################################
#################################################################################################################
#################################################################################################################
#################################################################################################################
#################################################################################################################
#################################################################################################################
#################################################################################################################
#################################################################################################################
#################################################################################################################
#scriptie netlogo data fragment
data_fragment <- read.csv("ecosysteem model fragmented habitat Pop dynamics scriptie fragment-spreadsheet.csv", header = FALSE) #lees excel in (wel al schoongemaakt - automatiseren?)
datalist2 <- list()


for(i in 1:nrow(data_fragment)){                                   #loop door de lines heen en maak ze clean nummers
  splitted2 <- strsplit(data_fragment[i,1], ",")[[1]]
  splitted2 <- splitted2[splitted2 != ""]
  splitted2 <- gsub('"', '', splitted2)
  num <- as.numeric(splitted2)
  
  mat2 <- matrix(num, ncol = 4, byrow=TRUE)
  
  datalist2[[i]] <- mat2
}

final_mat2 <- do.call(rbind, datalist2)                        #1 grote matrix met time en pop counts

data2 <- as.data.frame(final_mat2)
colnames(data2) <- c("Time2", "Foxes2", "Rabbits2", "Grass2")
data2$Experiment <- rep(1:10) # geef er even aan welke van de runs van netlogo het is, wordt eerst gezet als alles met time 0, alles met time 1 enz. 



#for Experiment 1-10 (als test)############################

data_list2 <- lapply(1:10, function(i) {
  data_exp2 <- data2 %>% filter(Experiment == i)
  data_long2 <- pivot_longer(data_exp2, cols = c("Foxes2", "Rabbits2", "Grass2"),
                            names_to = "Variable", values_to = "Value")
  
  list(
    Foxes2   = subset(data_long2, Variable == "Foxes2"),
    Rabbits2 = subset(data_long2, Variable == "Rabbits2"),
    Grass2   = subset(data_long2, Variable == "Grass2")
  )
})

Foxes2 <- data_list2[[1]]$Foxes2
Foxes2$Value <- (data_list2[[1]]$Foxes2$Value + data_list2[[2]]$Foxes2$Value + data_list2[[3]]$Foxes2$Value +
                   data_list2[[4]]$Foxes2$Value + data_list2[[5]]$Foxes2$Value + data_list2[[6]]$Foxes2$Value +
                   data_list2[[7]]$Foxes2$Value + data_list2[[8]]$Foxes2$Value + data_list2[[9]]$Foxes2$Value +
                   data_list2[[10]]$Foxes2$Value) / 10

# Rabbits2
Rabbits2 <- data_list2[[1]]$Rabbits2
Rabbits2$Value <- (data_list2[[1]]$Rabbits2$Value + data_list2[[2]]$Rabbits2$Value + data_list2[[3]]$Rabbits2$Value +
                     data_list2[[4]]$Rabbits2$Value + data_list2[[5]]$Rabbits2$Value + data_list2[[6]]$Rabbits2$Value +
                     data_list2[[7]]$Rabbits2$Value + data_list2[[8]]$Rabbits2$Value + data_list2[[9]]$Rabbits2$Value +
                     data_list2[[10]]$Rabbits2$Value) / 10

# Grass2
Grass2 <- data_list2[[1]]$Grass2
Grass2$Value <- (data_list2[[1]]$Grass2$Value + data_list2[[2]]$Grass2$Value + data_list2[[3]]$Grass2$Value +
                   data_list2[[4]]$Grass2$Value + data_list2[[5]]$Grass2$Value + data_list2[[6]]$Grass2$Value +
                   data_list2[[7]]$Grass2$Value + data_list2[[8]]$Grass2$Value + data_list2[[9]]$Grass2$Value +
                   data_list2[[10]]$Grass2$Value) / 10
Grass2$Value <- Grass2$Value /4
#############################################################
#plot time
################################################################################################
combined_df2 <- bind_rows(
  Foxes2 %>% mutate(Variable = "Foxes"),
  Rabbits2 %>% mutate(Variable = "Rabbits"),
  Grass2 %>% mutate(Variable = "Grass")
)
p2 <- ggplot(combined_df2, aes(x = Time2, y = Value, color = Variable)) +
  geom_line(linewidth = 1) +
  scale_color_manual(values = c("Foxes" = "red", "Rabbits" = "blue", "Grass" = "green")) +
  scale_y_continuous(limits = c(0, 1500)) +
  scale_x_continuous(limits = c(1000, 2000)) +
  labs(title = "Population over Time", x = "Time", y = "Value") +
  theme_minimal(base_size = 14)
print(p2)
ggsave("Population_over_Time_2.png", plot = p, width = 8, height = 5, dpi = 300)
####################################################################################################

#PLOT BASE CA1 phase space
################################################################################################################
###############################################################################################################
rgl.open()
bg3d(col = "white")  # clean background
view3d(theta = 45, phi = 30, zoom = 0.8)
par3d(windowRect = c(0, 0, 1300, 1000))  # 1100x1100 pixels window
plot3d(Rabbits2$Value, Foxes2$Value, Grass2$Value, col = "#346699" , size = 2, box = FALSE, xlim = range(380, 750), ylim = range(100, 350), zlim = range(700, 1300), xlab = "", ylab = "", zlab = "")

rgl.snapshot("CA13dview_frag.png")
###################################################################################################################
p1 <- ggplot(data.frame(Rabbits = Rabbits2$Value, Grass = Grass2$Value), aes(x = Rabbits, y = Grass)) +
  geom_point(alpha = 0.6, color = "#346699", size = 1) +
  labs(x = "Rabbits", y = "Grass", title = "Rabbits vs Grass CA1") +
  lims(x = range(350, 750), y = range(700, 1300))+ 
  theme_minimal()

print(p1)

# Save to file
ggsave("Rabbits_vs_Grass_frag.png", plot = p1, width = 7, height = 5, dpi = 300)
###################################################################################################################

p2 <- ggplot(data.frame(Foxes = Foxes2$Value, Grass = Grass2$Value), aes(x = Foxes, y = Grass)) +
  geom_point(shape = 16, alpha = 0.6, color = "#346699", size = 1) +
  labs(x = "Foxes", y = "Grass", title = "Foxes vs Grass CA1") +
  lims(x = range(100, 350), y = range(700, 1300))+
  theme_minimal()

print(p2)

# Save to file
ggsave("Foxes_vs_Grass_frag.png", plot = p2, width = 7, height = 5, dpi = 300)
###################################################################################################################

p3 <- ggplot(data.frame(Foxes = Foxes2$Value, Rabbits = Rabbits2$Value), aes(x = Foxes, y = Rabbits)) +
  geom_point(alpha = 0.6, color = "#346699", size = 1) +
  labs(x = "Foxes", y = "Rabbits", title = "Foxes vs Rabbits CA1") +
  lims(x = range(100, 350), y = range(350, 750))+
  theme_minimal()

print(p3)

# Save to file
ggsave("Foxes_vs_Rabbits_frag.png", plot = p3, width = 7, height = 5, dpi = 300)

###################################################################################################################
###################################################################################################################
##################################CENTROIDS ##################################################
###################################################################################################################
###################################################################################################################
###################################################################################################################
###################################################################################################################
###################################################################################################################
##################################CENTROIDS ##################################################
###################################################################################################################
###################################################################################################################
###################################################################################################################
#Centroids classic
data_classic_centroid <- read.csv("ecosysteem model classic Pop dynamics scriptie centroidcluod-spreadsheet.csv", header = FALSE) #lees excel in (wel al schoongemaakt - automatiseren?)
datalist_centroid1 <- list()

for(i in 1:nrow(data_classic_centroid)){                                   #loop door de lines heen en maak ze clean nummers
  splitted3 <- strsplit(data_classic_centroid[i,1], ",")[[1]]
  splitted3 <- splitted3[splitted3 != ""]
  splitted3 <- gsub('"', '', splitted3)
  num <- as.numeric(splitted3)
  
  mat3 <- matrix(num, ncol = 4, byrow=TRUE)
  
  datalist_centroid1[[i]] <- mat3
}


final_mat3 <- do.call(rbind, datalist_centroid1)                        #1 grote matrix met time en pop counts


data3 <- as.data.frame(final_mat3)
colnames(data3) <- c("Time3", "Foxes3", "Rabbits3", "Grass3")
data3$Experiment <- rep(1:100) # geef er even aan welke van de runs van netlogo het is, wordt eerst gezet als alles met time 0, alles met time 1 enz. 

classic_centroids <- data3 %>%
  group_by(Experiment) %>%
  summarise(mean_Foxes3 = mean(Foxes3),
            mean_rabbits3 = mean(Rabbits3),
            mean_grass3 = mean(Grass3))
classic_centroids

  

#Centroids frag
data_frag_centroid <- read.csv("ecosysteem model fragmented habitat Pop dynamics scriptie fragment centroid-spreadsheet.csv", header = FALSE) #lees excel in (wel al schoongemaakt - automatiseren?)
datalist_centroid2 <- list()

for(i in 1:nrow(data_frag_centroid)){                                   #loop door de lines heen en maak ze clean nummers
  splitted4 <- strsplit(data_frag_centroid[i,1], ",")[[1]]
  splitted4 <- splitted4[splitted4 != ""]
  splitted4 <- gsub('"', '', splitted4)
  num <- as.numeric(splitted4)
  
  mat4 <- matrix(num, ncol = 4, byrow=TRUE)
  
  datalist_centroid2[[i]] <- mat4
}


final_mat4 <- do.call(rbind, datalist_centroid2)                        #1 grote matrix met time en pop counts


data4 <- as.data.frame(final_mat4)
colnames(data4) <- c("Time4", "Foxes4", "Rabbits4", "Grass4")
data4$Experiment <- rep(1:100) # geef er even aan welke van de runs van netlogo het is, wordt eerst gezet als alles met time 0, alles met time 1 enz. 

frag_centroids <- data4 %>%
  group_by(Experiment) %>%
  summarise(mean_Foxes4 = mean(Foxes4),
            mean_rabbits4 = mean(Rabbits4),
            mean_grass4 = mean(Grass4))

#################################################### plotting centroids #######################################################
rgl.open()
bg3d(col = "white")
view3d(theta = 45, phi = 30, zoom = 0.8)
par3d(windowRect = c(0, 0, 1300, 1000))

# Use plot3d without disabling the box (so axes and labels show)
plot3d(
  classic_centroids$mean_Foxes3, 
  classic_centroids$mean_rabbits3, 
  classic_centroids$mean_grass3, 
  col = "#346699", size = 2,
  xlim = c(100, 400), ylim = c(450, 750), zlim = c(2500, 4000), box = FALSE
)

# Add the new points
points3d(
  frag_centroids$mean_Foxes4, 
  frag_centroids$mean_rabbits4, 
  frag_centroids$mean_grass4, 
  col = "red"
)



title3d(xlab = "Foxes", ylab = "Rabbits", zlab = "Grass", col = "black")
rgl.snapshot("centroid_comparison.png")



df_classic <- data.frame(Foxes = classic_centroids$Foxes,
                         Rabbits = classic_centroids$Rabbits,
                         Grass = classic_centroids$Grass,
                         Group = "Classic")

df_frag <- data.frame(Foxes = frag_centroids$Foxes,
                      Rabbits = frag_centroids$Rabbits,
                      Grass = frag_centroids$Grass,
                      Group = "Fragmented")

df_all <- rbind(df_classic, df_frag)

# Foxes vs Rabbits
centroidplot1 <- ggplot(df_all, aes(x = Foxes, y = Rabbits, color = Group)) +
  geom_point(size = 3) +
  scale_color_manual(values = c("Classic" = "#346699", "Fragmented" = "red")) +
  theme_minimal() +
  xlim(100, 400) + ylim(450, 750)
plot(centroidplot1)

ggsave("Centroid_Fox_Rab.png", plot = centroidplot1, width = 7, height = 5, dpi = 300)


# Foxes vs Grass
centroidplot2 <- ggplot(df_all, aes(x = Foxes, y = Grass, color = Group)) +
  geom_point(size = 3) +
  scale_color_manual(values = c("Classic" = "#346699", "Fragmented" = "red")) +
  theme_minimal() +
  xlim(100, 400) + ylim(2500, 4000)
plot(centroidplot2)

ggsave("Centroid_Fox_Grass.png", plot = centroidplot2, width = 7, height = 5, dpi = 300)

# Rabbits vs Grass
centroidplot3 <- ggplot(df_all, aes(x = Rabbits, y = Grass, color = Group)) +
  geom_point(size = 3) +
  scale_color_manual(values = c("Classic" = "#346699", "Fragmented" = "red")) +
  theme_minimal() +
  xlim(450, 750) + ylim(2500, 4000)

plot(centroidplot3)

ggsave("Centroid_Rab_Grass.png", plot = centroidplot3, width = 7, height = 5, dpi = 300)







classic_centroids$Group <- "A"
frag_centroids$Group <- "B"
names(classic_centroids)[c(2,3,4)] <- c("Foxes", "Rabbits", "Grass")
names(frag_centroids)[c(2,3,4)] <- c("Foxes", "Rabbits", "Grass")
all_centroids <- rbind(classic_centroids, frag_centroids)
manova_result <- manova(cbind(Foxes, Rabbits, Grass) ~ Group, data = all_centroids)
summary(manova_result, test = "Wilks")



median(Foxes2$Value)

